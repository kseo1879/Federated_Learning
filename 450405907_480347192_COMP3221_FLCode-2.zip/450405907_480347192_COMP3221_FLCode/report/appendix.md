# Appendix

**Figure 1: gd-vs-minibatch-accuracy**:
![gd-vs-minibatch-accuracy](./graphs/gd-vs-minibatch-accuracy.png)

**Figure 2: only-minibatch-accuracy**:
![gd-vs-minibatch-just-minibatch-accuracy](./graphs/only-minibatch-accuracy.png)

**Figure 3: gd-vs-minibatch-loss**:
![gd-vs-minibatch-loss](./graphs/gd-vs-minibatch-loss.png)

**Figure 4: sub-vs-nonsub-accuracy**:
![sub-vs-nonsub-accuracy](./graphs/sub-vs-nonsub-accuracy.png)

**Figure 5: sub-vs-nonsub-loss**:
![sub-vs-nonsub-loss](./graphs/sub-vs-nonsub-loss.png)

